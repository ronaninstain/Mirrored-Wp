<?php
// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

function lls_panel_page()
{
?>
    <div class="wrap">
        <div class="container">
            <div class="table-wrapper">
                <div class="table-title">
                    <div class="row">
                        <div class="col-sm-6">
                            <h3>Learner List</h3>
                        </div>
                        <div class="col-sm-6">
                            <!-- <a href="#addEmployeeModal" class="btn btn-success" data-toggle="modal"><i class="material-icons">&#xE147;</i> <span>Add New item</span></a>
                            <a href="#bulkEmployeeModal" class="btn btn-warning" data-toggle="modal"><i class="material-icons">&#xE15C;</i> <span>Bulk Item Add</span></a> -->
                        </div>
                    </div>
                </div>
                <table id="my-table-id2" class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Serial No</th>
                            <th>Learner Id</th>
                            <th>Learner Name</th>
                            <th>Email</th>
                            <th>Course Id</th>
                            <th>Course Name</th>
                            <th>Progress</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php

                        $client_ID = get_option('client_id', '');

                        $all_learner_list = 'https://course-dashboard.com/wp-json/custom-api/v1/learner-list/' . $client_ID;

                        $response_learners = wp_remote_get($all_learner_list);

                        if (is_wp_error($response_learners)) {
                            $error_message = $response_learners->get_error_message();
                            echo "Something went wrong: $error_message";
                        } else {
                            $learner_list = json_decode(wp_remote_retrieve_body($response_learners), true);

                            if (!empty($learner_list)) {
                                foreach ($learner_list as $learner) {
                                    echo '<tr>';
                                    echo '<td>' . $learner['id'] . '</td>';
                                    echo '<td>' . $learner['user_id'] . '</td>';
                                    echo '<td>' . $learner['name'] . '</td>';
                                    echo '<td>' . $learner['email'] . '</td>';
                                    echo '<td>' . $learner['course_id'] . '</td>';
                                    echo '<td>' . $learner['course_title'] . '</td>';
                                    echo '<td>' . $learner['progress'] . '</td>';
                                    echo '</tr>';
                                }
                            } else {
                                echo 'No learners found.';
                            }
                        }


                        ?>


                    </tbody>
                </table>

            </div>
        </div>

        <div id="toast" class="toast" style="display:none;">
            <div id="toast-message" class="toast-message"></div>
        </div>


        <!-- Add Modal HTML -->
        <?php
        // include(plugin_dir_path(__FILE__) . '/add-item-modal.php');
        // include(plugin_dir_path(__FILE__) . '/edit-item-modal.php');
        // include(plugin_dir_path(__FILE__) . '/delete-item-modal.php');
        // include(plugin_dir_path(__FILE__) . '/bulk-item-modal.php');
        ?>
    </div>
<?php
}
