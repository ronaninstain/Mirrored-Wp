<?php
/*
Plugin Name: Product to Course
Description: The plugin operation is product to Course join for B2B.
Version: 1.0
Author: mharif
License: GPL2
*/

// Prevent direct access to the file
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('PRODUCT_TO_COURSE_JOIN_VERSION', '1.0');
define('PRODUCT_TO_COURSE_JOIN_DIR', plugin_dir_path(__FILE__));
define('PRODUCT_TO_COURSE_JOIN_URL', plugin_dir_url(__FILE__));
define('PRODUCT_TO_COURSE_JOIN_TABLE', 'ptc_items');

// Include necessary files
// include_once PRODUCT_TO_COURSE_JOIN_DIR . 'admin/add-client.php';
include_once PRODUCT_TO_COURSE_JOIN_DIR . 'admin/manage-items.php';
include_once PRODUCT_TO_COURSE_JOIN_DIR . 'inc/db-operations.php';

// Register admin menu
function ptc_register_admin_menu()
{
    add_menu_page(
        'Product to Course',
        'Product to Course',
        'manage_options',
        'ptc-b2b-items',
        'ptc_items_list_page',
        'dashicons-businessman',
        6
    );
    add_submenu_page(
        'ptc-b2b-items',
        'Manage Items',
        'Manage Items',
        'manage_options',
        'ptc-b2b-items',
        'ptc_items_list_page'
    );

    add_submenu_page(
        'ptc-b2b-items',
        'Upcoming..',
        'Upcoming..',
        'manage_options',
        'ptc-add-client',
        'ptc_add_client_page'
    );
}
add_action('admin_menu', 'ptc_register_admin_menu');

function ptc_add_client_page()
{
    echo '<h2>Comming soon...</h2>';
}

// Register activation hook to create the database table
function ptc_plugin_activate()
{
    global $wpdb;
    $table_name = $wpdb->prefix . PRODUCT_TO_COURSE_JOIN_TABLE;

    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        product_id mediumint(9) NOT NULL,
        course_id mediumint(9) NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    // Include the upgrade script to handle the table creation
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
register_activation_hook(__FILE__, 'ptc_plugin_activate');

// Register deactivation hook to remove the database table
function ptc_plugin_deactivate()
{
    // global $wpdb;
    // $table_name = $wpdb->prefix . PRODUCT_TO_COURSE_JOIN_TABLE;
    // $sql = "DROP TABLE IF EXISTS $table_name;";
    // $wpdb->query($sql);
}
register_deactivation_hook(__FILE__, 'ptc_plugin_deactivate');


function ptc_enqueue_scripts($hook)
{
    wp_enqueue_script('ptc-ajax-script', PRODUCT_TO_COURSE_JOIN_URL . 'assets/js/ptc-ajax.js', array('jquery'), PRODUCT_TO_COURSE_JOIN_VERSION, true);
    wp_localize_script('ptc-ajax-script', 'ptc_ajax_obj', array(
        'ajax_url' => admin_url('admin-ajax.php'),
    ));

    if ($hook == 'toplevel_page_ptc-b2b-items') {
        // Enqueue your style
        wp_enqueue_style('ptc-b2b-items-style', plugin_dir_url(__FILE__) . 'assets/css/style.css');
        wp_enqueue_style('ptc-b2b-items-fonts.material', 'https://fonts.googleapis.com/icon?family=Material+Icons');
        wp_enqueue_style('ptc-b2b-items-fonts.varela', 'https://fonts.googleapis.com/css?family=Roboto|Varela+Round');
        wp_enqueue_style('ptc-b2b-items-fonts.aws', 'https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css');
        wp_enqueue_style('ptc-b2b-items-bootstrap', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css');

        wp_enqueue_script('ptc-b2b-items-jq-script', 'https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js', array('jquery'), '1.0', false);
        wp_enqueue_script('ptc-b2b-items-bootstrap-script', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js', array('jquery'), '1.0', false);

        // Enqueue DataTables CSS
        wp_enqueue_style('datatables-css', 'https://cdn.datatables.net/1.13.5/css/jquery.dataTables.min.css');
        // Enqueue DataTables JS
        wp_enqueue_script('datatables-js', 'https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js', array('jquery'), null, true);
    }
}
add_action('admin_enqueue_scripts', 'ptc_enqueue_scripts');
