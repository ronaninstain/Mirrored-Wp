//Add item script 
jQuery(document).ready(function($) {
    $('#add_item').on('submit', function(e) {
        e.preventDefault(); 
        
        var formData = new FormData(this); 
        formData.append('action', 'ptc_add_item'); 

        $.ajax({
            url: ptc_ajax_obj.ajax_url, 
            type: 'POST',
            data: formData,
            processData: false, 
            contentType: false, 
            success: function(response) {
                showToast(response.data); 
                if(response.data == 'Item added successfully'){
                    setTimeout(function() {
                        location.reload();
                    }, 2000); 
                }
                
            },
            error: function(response) {
                $('#preloader').hide();
                alert('There was an error adding the item.');
            }
        });
    });
});

// delete item script
jQuery(document).ready(function($) {

    $('.custom_click_delete').on('click', function() {
        var itemId = $(this).data('id');
        $('#delete_item').data('id', itemId); 
    });

    // Handle the delete form submission
    $('#delete_item').on('submit', function(e) {
        e.preventDefault(); 

        var itemId = $(this).data('id'); 

        $.ajax({
            url: ptc_ajax_obj.ajax_url, 
            type: 'POST',
            data: {
                action: 'ptc_delete_item',
                item_id: itemId
            },
            success: function(response) {
                if (response.success) {
                    
                    showToast('Item deleted successfully!'); 
                    setTimeout(function() {
                        location.reload();
                    }, 2000); 
                } else {
                    alert('Error: ' + response.data);
                }
            },
            error: function(response) {
                alert('There was an error deleting the item.');
            }
        });
    });
});


//edit or update item 
jQuery(document).ready(function($) {
 
    $('.custom_click_edit').on('click', function(e) {
        e.preventDefault(); 
        
        var itemId = $(this).data('id');
        $.ajax({
            url: ptc_ajax_obj.ajax_url, 
            type: 'POST',
            data: {
                action: 'ptc_get_item',
                item_id: itemId
            },
            success: function(response) {
                console.log(response);
                if (response.success) {
                    // console.log(response.data);
                    $('#edit_item input[name="product_id"]').val(response.data.product_id);
                    $('#edit_item input[name="course_id"]').val(response.data.course_id);
                    $('#edit_item').data('id', itemId); 
                } else {
                     alert('Error: ' + response.data);
                }
            },
            error: function(response) {
                alert('There was an error fetching the item data.');
            }
        });
    });

    // Handle the update form submission
    $('#edit_item').on('submit', function(e) {
        e.preventDefault(); 

        var formData = new FormData(this); 
        formData.append('action', 'ptc_update_item'); 
        formData.append('item_id', $(this).data('id')); 

        $.ajax({
            url: ptc_ajax_obj.ajax_url, 
            type: 'POST',
            data: formData,
            processData: false, 
            contentType: false, 
            success: function(response) {
                if (response.success) {
                    showToast('Item updated successfully!'); 
                    setTimeout(function() {
                        location.reload();
                    }, 2000); 
                } else {
                    alert('Error: ' + response.data);
                }
            },
            error: function(response) {
                alert('There was an error updating the item.');
            }
        });
    });
});

jQuery(document).ready(function($) {
    $('#bulk_item').on('submit', function(e) {
        e.preventDefault();

        var formData = new FormData(this);
        formData.append('action', 'bulk_add_items'); 
        console.log(formData);
        $.ajax({
            url: ptc_ajax_obj.ajax_url, 
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function(response) {
                // console.log(response);
                // if(response.data != 'Items already exist'){
                    showToast(response.data); 
                    setTimeout(function() {
                        location.reload();
                    }, 2000);
                // }else{
                //     showToast(response.data);
                // }
                
            },
            error: function(xhr, status, error) {
                alert('An error occurred: ' + error);
            }
        });
    });
});


jQuery(document).ready(function($) {
    $('#my-table-id2').DataTable({
        paging: true,
        searching: true,
        ordering: true,
        info: true,
    });
});


function showToast(message) {
    var toast = $('#toast');
    var toastMessage = $('#toast-message');

    toastMessage.text(message); 
    toast.addClass('toast-show'); 
    toast.show();

    setTimeout(function() {
        toast.removeClass('toast-show');
        toast.hide();
    }, 2000);
}