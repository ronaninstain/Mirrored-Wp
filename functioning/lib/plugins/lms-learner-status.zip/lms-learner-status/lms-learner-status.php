<?php
/*
Plugin Name: LMS Student Status
Description: The plugin operation get learner status from core site .
Version: 1.0
Author: mharif
License: GPL2
*/

// Prevent direct access to the file
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('LMS_LEARNER_STATUS_VERSION', '1.0');
define('LMS_LEARNER_STATUS_DIR', plugin_dir_path(__FILE__));
define('LMS_LEARNER_STATUS_URL', plugin_dir_url(__FILE__));

// define('LMS_LEARNER_STATUS_TABLE', 'lls_items');

// Include necessary files
// include_once LMS_LEARNER_STATUS_DIR . 'admin/add-client.php';
include_once LMS_LEARNER_STATUS_DIR . 'admin/manage-items.php';


// Register admin menu
function lls_register_admin_menu()
{
    add_menu_page(
        'LMS Student Status',
        'LMS Student Status',
        'manage_options',
        'lls-b2b-items',
        'lls_panel_page',
        'dashicons-businessman',
        9
    );
    add_submenu_page(
        'lls-b2b-items',
        'Learner List',
        'Learner List',
        'manage_options',
        'lls-b2b-items',
        'lls_panel_page'
    );

    add_submenu_page(
        'lls-b2b-items',
        'Upcoming..',
        'Upcoming..',
        'manage_options',
        'lls-add-client',
        'lls_add_client_page'
    );
}
add_action('admin_menu', 'lls_register_admin_menu');

function lls_add_client_page()
{
    echo '<h2>Comming soon...</h2>';
}

// Register activation hook to create the database table
// function lls_plugin_activate()
// {
//     global $wpdb;
//     $table_name = $wpdb->prefix . LMS_LEARNER_STATUS_TABLE;

//     $charset_collate = $wpdb->get_charset_collate();
//     $sql = "CREATE TABLE $table_name (
//         id mediumint(9) NOT NULL AUTO_INCREMENT,
//         product_id mediumint(9) NOT NULL,
//         course_id mediumint(9) NOT NULL,
//         created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
//         PRIMARY KEY (id)
//     ) $charset_collate;";

//     require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
//     dbDelta($sql);
// }
// register_activation_hook(__FILE__, 'lls_plugin_activate');

// Register deactivation hook to remove the database table
// function lls_plugin_deactivate()
// {
//     global $wpdb;
//     $table_name = $wpdb->prefix . LMS_LEARNER_STATUS_TABLE;
//     $sql = "DROP TABLE IF EXISTS $table_name;";
//     $wpdb->query($sql);
// }
// register_deactivation_hook(__FILE__, 'lls_plugin_deactivate');


function lls_enqueue_scripts($hook)
{
    // wp_enqueue_script('ptc-ajax-script', LMS_LEARNER_STATUS_URL . 'assets/js/ptc-ajax.js', array('jquery'), LMS_LEARNER_STATUS_VERSION, true);
    // wp_localize_script('ptc-ajax-script', 'lls_ajax_obj', array(
    //     'ajax_url' => admin_url('admin-ajax.php'),
    // ));

    if ($hook == 'toplevel_page_lls-b2b-items') {
        wp_enqueue_style('lls-b2b-items-style', plugin_dir_url(__FILE__) . 'assets/css/style.css');
        wp_enqueue_style('lls-b2b-items-fonts.material', 'https://fonts.googleapis.com/icon?family=Material+Icons');
        wp_enqueue_style('lls-b2b-items-fonts.varela', 'https://fonts.googleapis.com/css?family=Roboto|Varela+Round');
        wp_enqueue_style('lls-b2b-items-fonts.aws', 'https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css');
        wp_enqueue_style('lls-b2b-items-bootstrap', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css');

        wp_enqueue_script('lls-b2b-items-jq-script', 'https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js', array('jquery'), '1.0', false);
        wp_enqueue_script('lls-b2b-items-bootstrap-script', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js', array('jquery'), '1.0', false);

        wp_enqueue_style('datatables-css', 'https://cdn.datatables.net/1.13.5/css/jquery.dataTables.min.css');
        wp_enqueue_script('datatables-js', 'https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js', array('jquery'), null, true);
    }
}
add_action('admin_enqueue_scripts', 'lls_enqueue_scripts');
