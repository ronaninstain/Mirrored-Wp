<?php
// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

function ptc_items_list_page()
{
?>
    <div class="wrap">
        <div class="container">
            <div class="table-wrapper">
                <div class="table-title">
                    <div class="row">
                        <div class="col-sm-6">
                            <h3>Manage <b>items</b></h3>
                        </div>
                        <div class="col-sm-6">
                            <a href="#addEmployeeModal" class="btn btn-success" data-toggle="modal"><i class="material-icons">&#xE147;</i> <span>Add New item</span></a>
                            <a href="#bulkEmployeeModal" class="btn btn-warning" data-toggle="modal"><i class="material-icons">&#xE15C;</i> <span>Bulk Item Add</span></a>
                        </div>
                    </div>
                </div>
                <table id="my-table-id2" class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Serial No</th>
                            <th>Product Id</th>
                            <th>Course Id</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $items = ptc_get_all_items();
                        if ($items) {
                            foreach ($items as $item) {
                        ?>
                                <tr>
                                    <td><?php echo esc_html($item['id']); ?></td>
                                    <td><?php echo esc_html($item['product_id']); ?></td>
                                    <td><?php echo esc_html($item['course_id']); ?></td>
                                    <td>
                                        <a href="#editEmployeeModal" class="custom_click_edit" data-toggle="modal" data-id="<?php echo $item['id']; ?>"><i class="material-icons" data-toggle="tooltip" title="Edit">&#xE254;</i></a>
                                        <a href="#deleteEmployeeModal" class="custom_click_delete" data-toggle="modal" data-id="<?php echo $item['id']; ?>"><i class="material-icons" data-toggle="tooltip" title="Delete">&#xE872;</i></a>
                                    </td>
                                </tr>
                            <?php
                            }
                        } else {
                            ?>
                            <tr>
                                <td colspan="8">No items found.</td>
                            </tr>
                        <?php
                        }
                        ?>


                    </tbody>
                </table>

            </div>
        </div>

        <div id="toast" class="toast" style="display:none;">
            <div id="toast-message" class="toast-message"></div>
        </div>


        <!-- Add Modal HTML -->
        <?php
        include(plugin_dir_path(__FILE__) . '/add-item-modal.php');
        include(plugin_dir_path(__FILE__) . '/edit-item-modal.php');
        include(plugin_dir_path(__FILE__) . '/delete-item-modal.php');
        include(plugin_dir_path(__FILE__) . '/bulk-item-modal.php');
        ?>
    </div>
<?php
}
