<?php

function ptc_add_item_ajax_handler()
{
    global $wpdb;

    // Sanitize input data
    $productID = sanitize_text_field($_POST['product_id']);
    $courseID = sanitize_text_field($_POST['course_id']);

    // Define the table name
    $table_name = $wpdb->prefix . 'ptc_items';

    // Check if the combination of product_id and course_id already exists
    $existing_entry = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table_name WHERE product_id = %s AND course_id = %s",
        $productID,
        $courseID
    ));

    if ($existing_entry > 0) {
        wp_send_json_error('This product and course combination already exists.');
        return;
    }

    // Insert the data into the database
    $result = $wpdb->insert(
        $table_name,
        array(
            'product_id' => $productID,
            'course_id' => $courseID,
            'created_at' => current_time('mysql')
        ),
        array(
            '%s',
            '%s',
            '%s'
        )
    );

    if ($result) {
        wp_send_json_success('Item added successfully');
    } else {
        wp_send_json_error('Failed to add item.');
    }
}
add_action('wp_ajax_ptc_add_item', 'ptc_add_item_ajax_handler');
add_action('wp_ajax_nopriv_ptc_add_item', 'ptc_add_item_ajax_handler');

// get all data from database 
function ptc_get_all_items()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'ptc_items';

    $items = $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);

    return $items;
}

// delete item data 
function ptc_delete_item_ajax_handler()
{
    global $wpdb;

    $item_id = intval($_POST['item_id']);

    if ($item_id > 0) {
        $table_name = $wpdb->prefix . 'ptc_items';

        $deleted = $wpdb->delete($table_name, array('id' => $item_id), array('%d'));

        if ($deleted) {
            wp_send_json_success('item deleted successfully.');
        } else {
            wp_send_json_error('Failed to delete item.');
        }
    } else {
        wp_send_json_error('Invalid item ID.');
    }
}
add_action('wp_ajax_ptc_delete_item', 'ptc_delete_item_ajax_handler');
add_action('wp_ajax_nopriv_ptc_delete_item', 'ptc_delete_item_ajax_handler');

// get data for modal view 
function ptc_get_item_ajax_handler()
{
    global $wpdb;

    $item_id = intval($_POST['item_id']);
    // wp_send_json($_POST['item_id']);

    if ($item_id > 0) {
        $table_name = $wpdb->prefix . 'ptc_items';
        $item = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $item_id), ARRAY_A);
        if ($item) {
            wp_send_json_success($item);
        } else {
            wp_send_json_error('item not found.');
        }
    } else {
        wp_send_json_error('Invalid item ID.');
    }
}
add_action('wp_ajax_ptc_get_item', 'ptc_get_item_ajax_handler');
add_action('wp_ajax_nopriv_ptc_get_item', 'ptc_get_item_ajax_handler');

// finally update data 
function ptc_update_item_ajax_handler()
{
    global $wpdb;
    $item_id = intval($_POST['item_id']);
    if ($item_id > 0) {
        $table_name = $wpdb->prefix . 'ptc_items';
        $data = array(
            'product_id' => sanitize_text_field($_POST['product_id']),
            'course_id' => sanitize_text_field($_POST['course_id']),
        );

        $where = array('id' => $item_id);

        $updated = $wpdb->update($table_name, $data, $where, null, array('%d'));

        if ($updated !== false) {
            wp_send_json_success('item updated successfully.');
        } else {
            wp_send_json_error('Failed to update item.');
        }
    } else {
        wp_send_json_error('Invalid item ID.');
    }
}
add_action('wp_ajax_ptc_update_item', 'ptc_update_item_ajax_handler');
add_action('wp_ajax_nopriv_ptc_update_item', 'ptc_update_item_ajax_handler');


add_action('wp_ajax_bulk_add_items', 'bulk_add_items');
add_action('wp_ajax_nopriv_bulk_add_items', 'bulk_add_items');

function bulk_add_items()
{
    global $wpdb;

    if (isset($_FILES['customFile']['tmp_name'])) {
        $csvFile = fopen($_FILES['customFile']['tmp_name'], 'r');
        $rowCount = 0;
        $insertCount = 0;
        $skipCount = 0;

        fgetcsv($csvFile);

        while (($row = fgetcsv($csvFile, 1000, ",")) !== FALSE) {
            $rowCount++;
            $product_id = intval($row[0]);
            $course_id = intval($row[1]);

            if (empty($product_id) || empty($course_id)) {
                continue;
            }
            $existing_item = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT * FROM {$wpdb->prefix}ptc_items WHERE product_id = %d AND course_id = %d",
                    $product_id,
                    $course_id
                )
            );

            if (is_null($existing_item)) {
                $data = array(
                    'product_id' => $product_id,
                    'course_id'  => $course_id
                );

                $result = $wpdb->insert($wpdb->prefix . 'ptc_items', $data);

                if ($result !== false) {
                    $insertCount++;
                }
            } else {
                $skipCount++;
            }
        }

        fclose($csvFile);
        wp_send_json_success('Items have been successfully added');
    } else {
        wp_send_json_success('No file uploaded or file is not valid.');
    }

    wp_die();
}
