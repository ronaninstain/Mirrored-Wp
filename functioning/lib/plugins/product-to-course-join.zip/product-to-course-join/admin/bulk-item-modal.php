<div id="bulkEmployeeModal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="bulk_item" method="post" enctype="multipart/form-data">
                <div class="modal-header">
                    <h4 class="modal-title">Bulk Add Item</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                </div>
                <div class="modal-body">
                    <label class="form-label" for="customFile">CSV file format input example</label>
                    <input type="file" class="form-control" name="customFile" />
                </div>
                <div class="modal-footer">
                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                    <input type="submit" class="btn btn-warning" value="Add">
                </div>
            </form>
        </div>
    </div>
</div>